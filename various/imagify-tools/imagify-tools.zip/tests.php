<?php
defined( 'ABSPATH' ) || die( 'Cheatin’ uh?' );

global $wpdb, $wp_filter, $wp_rewrite;

$filesystem = imagify_tools_get_filesystem();
